# Security & Compliance Checklist — Fintech / Web3 Brasil

> Cole este checklist direto no Jira/Trello. Um item = um card.
> Baseado no arcabouço BaaS (Res. Conjunta CMN/BCB 16/2025), PSAV (Res. BCB 519/520/521),
> Lei 14.478/2022, Circular BCB 3.978/2020 (PLD/FT) e LGPD.

## 1. Segregação de Trilhos
- [ ] Arquitetura separa explicitamente o trilho Fiat (BaaS) do trilho de Ativos Virtuais (PSAV)
- [ ] Nenhum componente técnico compartilha estado/credenciais entre os dois trilhos
- [ ] Contratos e comunicação com o cliente final deixam claro qual trilho está em uso
- [ ] Histórico de negociações com provedores anteriores está documentado e declarável

## 2. Segurança Técnica
- [ ] mTLS configurado na integração com o(s) provedor(es)
- [ ] Certificados de cliente com rotação programada
- [ ] Validação de assinatura HMAC em todos os webhooks recebidos
- [ ] Egress via IP estático dedicado (allowlist do provedor)
- [ ] Sandbox e produção isolados (projetos/redes distintos, sem credenciais compartilhadas)
- [ ] Segredos em cofre gerenciado (nunca `.env` versionado em texto puro)
- [ ] Rotação de credenciais configurada
- [ ] IAM com princípio de menor privilégio
- [ ] Logs em modo WORM (retenção travada / imutável)
- [ ] TLS 1.2+ em trânsito
- [ ] AES-256 em repouso (CMEK/chave gerenciada pelo cliente, se disponível)
- [ ] Backups automatizados multirregião
- [ ] RTO/RPO documentados e testados (não apenas declarados)

## 3. KYC / KYB
- [ ] Validação documental + biometria facial + prova de vida no onboarding
- [ ] Consulta a listas restritivas (OFAC, ONU, UE) e bases de PEP
- [ ] KYB reconstruindo cadeia societária até o beneficiário final (para PJ)
- [ ] Atualização cadastral periódica configurada

## 4. PLD/FT
- [ ] Política de PLD/FT aprovada pela administração (abordagem baseada em risco)
- [ ] Diretor responsável por PLD/FT formalmente nomeado em ata
- [ ] Monitoramento transacional com regras paramétricas + detecção de anomalias
- [ ] Fluxo de comunicação de operações suspeitas ao COAF (com trilha de decisão)
- [ ] Travel Rule implementada (se houver camada PSAV)
- [ ] Treinamento anual de PLD/FT agendado para equipe e diretoria

## 5. LGPD
- [ ] DPO (encarregado de dados) designado
- [ ] RIPD (Relatório de Impacto à Proteção de Dados) elaborado para o fluxo de onboarding
- [ ] Base legal de tratamento de dados documentada por finalidade

## 6. Antes de Protocolar o Onboarding com um Provedor
- [ ] Estatuto social + atas de eleição da diretoria atualizados
- [ ] Cartão CNPJ + certidões negativas (federal, estadual, municipal, trabalhista)
- [ ] Organograma societário com beneficiários finais (assinado)
- [ ] Demonstrações financeiras do último exercício
- [ ] Parecer jurídico sobre o enquadramento do ativo (ativo virtual vs. valor mobiliário)
- [ ] Comprovante de origem de recursos do capital social
- [ ] Política de segurança da informação + plano de resposta a incidentes

---
*Parte do Fintech Secure Starter Kit 2026 — VERTICALAGENT / AIBANK*

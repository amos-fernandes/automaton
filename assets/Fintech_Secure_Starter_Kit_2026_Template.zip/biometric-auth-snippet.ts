/**
 * biometric-auth-snippet.ts
 * Fintech Secure Starter Kit 2026 — VERTICALAGENT / AIBANK
 *
 * Estrutura de referência para biometria + prova de vida (liveness) no
 * onboarding, em React Native (Expo). Cobre o item de KYC biométrico
 * do Capítulo 4 do ebook. Troque o provedor de liveness pelo que sua
 * fintech já usa (o ponto aqui é a ESTRUTURA do fluxo, não o SDK).
 */

import * as LocalAuthentication from "expo-local-authentication";
import { useState, useCallback } from "react";

export type OnboardingBiometricResult = {
  status: "success" | "failed" | "unsupported" | "cancelled";
  livenessScore?: number;
  documentMatchScore?: number;
  timestamp: string;
};

/**
 * Passo 1 — autenticação biométrica local do dispositivo (Face ID /
 * impressão digital), usada para desbloquear o app após o cadastro,
 * NÃO substitui a etapa de prova de vida do KYC.
 */
export async function authenticateLocalBiometrics(): Promise<boolean> {
  const hasHardware = await LocalAuthentication.hasHardwareAsync();
  const isEnrolled = await LocalAuthentication.isEnrolledAsync();

  if (!hasHardware || !isEnrolled) return false;

  const result = await LocalAuthentication.authenticateAsync({
    promptMessage: "Confirme sua identidade",
    fallbackLabel: "Usar senha",
    disableDeviceFallback: false,
  });

  return result.success;
}

/**
 * Passo 2 — fluxo de KYC biométrico (prova de vida + confronto com
 * documento). Este é o passo que efetivamente conta para o programa
 * de PLD/FT — deve rodar no onboarding e, se sua política exigir,
 * ser repetido periodicamente.
 *
 * Delegue a captura/liveness a um provedor especializado (SDK nativo
 * ou fluxo web embutido) e trate o resultado aqui.
 */
export function useKycOnboarding() {
  const [status, setStatus] = useState<OnboardingBiometricResult["status"]>("unsupported");
  const [loading, setLoading] = useState(false);

  const runKycFlow = useCallback(async (documentImageUri: string) => {
    setLoading(true);
    try {
      // Substitua pela chamada real ao seu provedor de liveness/KYC.
      // Mantenha a chave de API do provedor em cofre de segredos —
      // nunca embutida no bundle do app.
      const response = await fetch(`${process.env.EXPO_PUBLIC_API_URL}/kyc/verify`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ documentImageUri }),
      });

      if (!response.ok) {
        setStatus("failed");
        return { status: "failed", timestamp: new Date().toISOString() } as OnboardingBiometricResult;
      }

      const data = await response.json();
      const result: OnboardingBiometricResult = {
        status: data.livenessScore >= 0.85 ? "success" : "failed",
        livenessScore: data.livenessScore,
        documentMatchScore: data.documentMatchScore,
        timestamp: new Date().toISOString(),
      };

      setStatus(result.status);
      // TODO: persistir resultado + timestamp na trilha de auditoria (WORM)
      return result;
    } finally {
      setLoading(false);
    }
  }, []);

  return { status, loading, runKycFlow };
}

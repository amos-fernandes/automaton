/**
 * mtls-server-example.js
 * Fintech Secure Starter Kit 2026 — VERTICALAGENT / AIBANK
 *
 * Exemplo de servidor Fastify configurado para consumir/expor endpoints
 * de um provedor BaaS/PSAV usando mutual TLS (mTLS) + validação de
 * assinatura HMAC em webhooks — os dois primeiros itens do checklist
 * do Capítulo 2 do ebook.
 *
 * Substitua os placeholders (CERT_PATH, KEY_PATH, CA_PATH, WEBHOOK_SECRET)
 * pelos valores reais, sempre vindos de um cofre de segredos gerenciado
 * (Secret Manager / Vault) — nunca hardcoded ou em .env versionado.
 */

const fs = require("fs");
const crypto = require("crypto");
const Fastify = require("fastify");

const CERT_PATH = process.env.MTLS_CLIENT_CERT_PATH; // certificado do cliente
const KEY_PATH = process.env.MTLS_CLIENT_KEY_PATH;    // chave privada do cliente
const CA_PATH = process.env.MTLS_CA_PATH;             // CA do provedor (para validar o servidor)
const WEBHOOK_SECRET = process.env.PROVIDER_WEBHOOK_SECRET; // segredo HMAC do provedor

const fastify = Fastify({
  logger: true,
  // Em produção: exigir mTLS na conexão de entrada (client cert do provedor)
  https: {
    key: fs.readFileSync(process.env.SERVER_KEY_PATH),
    cert: fs.readFileSync(process.env.SERVER_CERT_PATH),
    ca: fs.readFileSync(CA_PATH),
    requestCert: true,
    rejectUnauthorized: true, // recusa conexão sem certificado de cliente válido
  },
});

/**
 * Cliente HTTPS com mTLS para CHAMAR a API do provedor
 * (usar via https.Agent em node-fetch/axios/undici)
 */
function buildMtlsAgent() {
  const https = require("https");
  return new https.Agent({
    cert: fs.readFileSync(CERT_PATH),
    key: fs.readFileSync(KEY_PATH),
    ca: fs.readFileSync(CA_PATH),
    rejectUnauthorized: true,
  });
}

/**
 * Valida assinatura HMAC de um webhook recebido do provedor.
 * Descarta qualquer payload cuja assinatura não bata — evita
 * processar callbacks forjados.
 */
function verifyWebhookSignature(rawBody, signatureHeader) {
  const expected = crypto
    .createHmac("sha256", WEBHOOK_SECRET)
    .update(rawBody)
    .digest("hex");

  const provided = Buffer.from(signatureHeader || "", "utf8");
  const expectedBuf = Buffer.from(expected, "utf8");

  if (provided.length !== expectedBuf.length) return false;
  return crypto.timingSafeEqual(provided, expectedBuf);
}

// Endpoint que recebe webhooks do provedor BaaS/PSAV
fastify.post(
  "/webhooks/provider",
  { config: { rawBody: true } },
  async (request, reply) => {
    const signature = request.headers["x-provider-signature"];
    const rawBody = request.rawBody; // configurar plugin fastify-raw-body

    if (!verifyWebhookSignature(rawBody, signature)) {
      request.log.warn("Webhook com assinatura inválida — descartado");
      return reply.code(401).send({ error: "invalid_signature" });
    }

    const event = JSON.parse(rawBody);
    request.log.info({ eventType: event.type }, "Webhook validado");

    // TODO: enfileirar processamento assíncrono (idempotente por event.id)
    return reply.code(200).send({ received: true });
  }
);

// Exemplo de chamada de saída ao provedor usando o agente mTLS
async function callProviderApi(path, body) {
  const { default: fetch } = await import("node-fetch");
  const agent = buildMtlsAgent();

  const res = await fetch(`https://api.provedor-baas.example.com${path}`, {
    method: "POST",
    agent,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    throw new Error(`Provider API error: ${res.status}`);
  }
  return res.json();
}

const start = async () => {
  try {
    await fastify.listen({ port: process.env.PORT || 8443, host: "0.0.0.0" });
  } catch (err) {
    fastify.log.error(err);
    process.exit(1);
  }
};

module.exports = { fastify, verifyWebhookSignature, callProviderApi };
if (require.main === module) start();
